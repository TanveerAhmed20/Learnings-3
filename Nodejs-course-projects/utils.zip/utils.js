// file containing useful utilities

const value = 1;
const result= 2;

module.exports = {
    value,
    result
};

