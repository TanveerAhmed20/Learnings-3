const name = "tanveer";

const {result,value} = require('./utils');



console.log(result);
console.log(value);