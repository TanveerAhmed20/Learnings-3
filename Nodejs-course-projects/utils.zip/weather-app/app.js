const apiAccesskey = "ea3a7922a46cce11b334fc277ec4a5ca";

const url = "https://weatherstack.com/current?"